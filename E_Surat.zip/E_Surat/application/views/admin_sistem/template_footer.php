<footer class="main-footer">
	<strong>Copyright &copy; 2020 <a href="http://localhost/e_surat/">E Surat Dukuh Dempok</a>.</strong>
	All rights reserved.
	<div class="float-right d-none d-sm-inline-block">
		<b>Version</b> 0.0.1
	</div>
</footer>
