<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="text-dark"><strong><?=$title_content?></strong></h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<?= $breadcrumb ?>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
